import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ResetPasswordService } from '../../services/reset-password.service';
import { AlertService } from 'src/app/shared/services/alert.service';
import { ResetPassword } from '../../interfaces/reset-password';
import { ResponseData } from 'src/app/auth/interfaces/response-data';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.css']
})
export class ResetPasswordComponent implements OnInit{
  ChangePassword!:FormGroup;
  token: string ="";
  email: string = "";
  actifLoader: boolean = false;
  // mailPassWordReset

  constructor(
    private route: ActivatedRoute,
    private resetPasswordRessource:ResetPasswordService,
    private fb:FormBuilder,
    private alertService:AlertService,
    private router:Router
    ){}

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      this.token = params['token'];
      this.email = params['email'];
    });

    this.ChangePassword = this.fb.group({
      "email":[this.email,[Validators.required,Validators.email]],
      "token":[this.token,[Validators.required]],
      "password":["",[Validators.required]],
      "password_confirmation":["",[Validators.required]],
    })
  }


  resetPassword(){
    this.actifLoader = true;
    this.resetPasswordRessource.postData<ResetPassword,ResponseData<any[]>>('user/password/reset',this.ChangePassword.value).subscribe(
      {
        next: (data) => {
          this.alertService.showAlert({
            title: "Success",
            text: data.message,
            icon: "success"
          })
          this.router.navigate(['/auth']);
        },
        error: (err) => {
          this.alertService.showAlert({
            title: "Erreur",
            text: err.message,
            icon: "warning"
          })
          this.actifLoader = false;
        },
        complete:() => {
          this.actifLoader = false;
        },
      }
    )
  }

}
