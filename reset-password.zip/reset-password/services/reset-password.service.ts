import { Injectable } from '@angular/core';
import { ParentService } from 'src/app/shared/services/parent.service';
import { ResetPassword } from '../interfaces/reset-password';

@Injectable({
  providedIn: 'root'
})
export class ResetPasswordService extends ParentService{

}
